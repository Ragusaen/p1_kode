/******************************************************************************
 * Automatic detection of clickbait
 * 
 * @version     3.2
 * @studygroup  DAT1A307
 * @year        2018
 ******************************************************************************/

#include <stdlib.h>

#include "io/interface.h"


int main(int argc, const char **argv)
{
    interface_init(argc, argv);

    return EXIT_SUCCESS;
}